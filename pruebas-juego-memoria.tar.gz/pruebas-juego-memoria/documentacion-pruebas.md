# Documentación de Pruebas Unitarias — Juego de Memoria

**Fecha de ejecución:** 2 de junio de 2026  
**Framework:** JUnit Jupiter 5.10.1  
**Herramienta de build:** Apache Maven 3 + Surefire Plugin 3.2.2  
**Resultado general:** ✅ 13/13 pruebas pasaron — BUILD SUCCESS

---

## Resumen de resultados

| Clase de prueba | Pruebas ejecutadas | Fallos | Errores | Omitidas | Tiempo |
|---|---|---|---|---|---|
| `TarjetaTest` | 8 | 0 | 0 | 0 | 0.044 s |
| `TableroTest` | 5 | 0 | 0 | 0 | 0.005 s |
| **TOTAL** | **13** | **0** | **0** | **0** | **~0.05 s** |

---

## TarjetaTest — Pruebas de la clase `Tarjeta`

La clase `Tarjeta` representa una tarjeta individual del juego. Cada tarjeta tiene una fruta, un estado de visibilidad y un contador de veces que fue volteada.

### Pruebas incluidas

| # | Nombre del método | Qué verifica |
|---|---|---|
| 1 | `tarjetaIniciaOculta` | Una tarjeta recién creada debe estar boca abajo (`estaVolteada = false`) |
| 2 | `voltearDejaVisible` | Al llamar a `voltear()` una vez, la tarjeta queda visible |
| 3 | `voltearDosVecesVuelveAOcultar` | Al voltear dos veces, la tarjeta regresa a estar oculta |
| 4 | `contadorIncrementaConCadaVolteo` | El contador `vecesVolteada` aumenta correctamente con cada llamada a `voltear()` |
| 5 | `tarjetaIniciaNoEncontrada` | Al crearla, `fueEncontrada` debe ser `false` |
| 6 | `marcarComoEncontradaFunciona` | `marcarComoEncontrada()` pone `fueEncontrada` en `true` |
| 7 | `marcarComoEncontradaDejaVisible` | Al marcar como encontrada, la tarjeta también queda visible |
| 8 | `getFrutaRetornaFrutaCorrecta` | `getFruta()` retorna exactamente la fruta pasada al constructor |

---

## TableroTest — Pruebas de la clase `Tablero`

La clase `Tablero` administra todas las tarjetas del juego: las crea, las mezcla aleatoriamente y verifica si dos tarjetas seleccionadas forman pareja.

### Pruebas incluidas

| # | Nombre del método | Qué verifica |
|---|---|---|
| 1 | `tableroTieneOchoTarjetas` | El tablero siempre contiene exactamente 8 tarjetas (4 pares) |
| 2 | `juegoNoTerminaAlInicio` | Al inicio, `juegoTerminado()` debe retornar `false` |
| 3 | `verificarParejaRetornaTrueConFrutasIguales` | Dos tarjetas con la misma fruta son reconocidas como pareja y marcadas como encontradas |
| 4 | `verificarParejaRetornaFalseConFrutasDistintas` | Dos tarjetas con frutas distintas no forman pareja y se vuelven a ocultar |
| 5 | `juegoTerminaCuandoTodasEncontradas` | Cuando todas las tarjetas están marcadas como encontradas, `juegoTerminado()` retorna `true` |

---

## Estructura del proyecto de pruebas

```
juego-memoria/
├── pom.xml                          <- Configuración Maven con JUnit 5
├── src/
│   ├── main/java/
│   │   ├── Main.java                <- Lógica principal del juego
│   │   ├── Tablero.java             <- Gestión del tablero
│   │   └── Tarjeta.java             <- Modelo de tarjeta
│   └── test/java/
│       ├── TarjetaTest.java         <- 8 pruebas unitarias de Tarjeta
│       └── TableroTest.java         <- 5 pruebas unitarias de Tablero
└── target/surefire-reports/         <- Reportes generados automáticamente
    ├── TarjetaTest.txt
    ├── TableroTest.txt
    ├── TEST-TarjetaTest.xml
    └── TEST-TableroTest.xml
```

---

## Cómo ejecutar las pruebas

Desde la raíz del proyecto `juego-memoria/`, ejecutar:

```bash
mvn test
```

Los reportes se generan automáticamente en `target/surefire-reports/`.
